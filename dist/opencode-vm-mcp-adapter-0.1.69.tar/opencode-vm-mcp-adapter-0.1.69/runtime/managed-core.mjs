// The VM/host credential and origin separation is the primary remote boundary.
// These rules are the additional OpenCode work-session behavior contract.
export const REVISION = 1;
export const PRIMER = `This work session is agent-managed by its backend ingress.
Follow the authorized task scope. Explicit read-only/review/task restrictions still apply.
Do not open questions, quizzes or other end-user dialogs. If a business decision is missing, end the turn with INPUT_REQUIRED, the concrete decision, context, safe options, completed work and paused work. The orchestrator supplies a normal follow-up in this same session.`;
export const COMMIT_SENTENCE = "Only commit, amend, push, or create PRs when explicitly requested.";
export const LEGACY_VM_ASK = "If the request is ambiguous or you see multiple reasonable interpretations, surface them and ask before implementing. If no user is available to ask (autonomous or A2A runs), choose the most minimal interpretation consistent with the request and state the assumption in your report.";
export const MANAGED_VM_ASK = "This is backend agent-managed work: document safe reversible assumptions within the authorized scope. If a business/product decision is missing, pause dependent work and return a terminal INPUT_REQUIRED report with question, context and options; the orchestrator supplies a normal follow-up. Do not open a native end-user question.";

const same = (a, b) => a.permission === b.permission && a.pattern === b.pattern && a.action === b.action;
const remoteRules = ["git push", "git push *", "git send-pack *", "git http-push *", "git receive-pack *", "git lfs push *", "git lfs upload *"].map(pattern => ({ permission: "bash", pattern, action: "deny" }));

// Mirrors OpenCode's Wildcard.match (packages/opencode/src/util/wildcard.ts):
// backslashes become "/", "*" any span, "?" one char, a trailing " *" may be
// absent; the match is anchored. Used only to reason about rule precedence.
export function matchesGlob(str, pattern) {
  const value = String(str ?? "").replaceAll("\\", "/");
  let escaped = String(pattern ?? "").replaceAll("\\", "/")
    .replace(/[.+^${}()|[\]]/g, "\\$&")
    .replace(/\*/g, ".*")
    .replace(/\?/g, ".");
  if (escaped.endsWith(" .*")) escaped = escaped.slice(0, -3) + "( .*)?";
  return new RegExp(`^${escaped}$`, "s").test(value);
}

// OpenCode's built-in agent defaults carry a generic "*": "allow" and an
// interactive external_directory "*": "ask". Copying agent rules into session
// rules would (a) propagate that ask into deriveSubagentSessionPermission,
// where the child keeps the inherited ask but drops the parent's generic allow
// (1.19.0 agent/subagent-permissions.ts), and (b) turn the copied generic
// allow into a LATER session-level rule that silently overrides the agent's
// own remaining asks (external, doom_loop, .env reads). Dropping exactly the
// generic blanket allow and the default external ask from the COPY keeps the
// agent rules themselves, explicit user rules and all denies intact.
const copyableAgentRules = rules => rules.filter(rule => !((rule.permission === "*" && rule.pattern === "*" && rule.action === "allow") || (rule.permission === "external_directory" && rule.action === "ask" && rule.pattern === "*")));

// Explicit deny rules (external_directory or "*", matching the directory
// itself or its allow pattern) always win over an authorized scope allow.
export function scopeAllowRules(agentRules = [], scope = [], dirs = []) {
  const denies = [...agentRules, ...scope].filter(rule => rule.action === "deny");
  return dirs
    .filter(dir => !denies.some(rule => matchesGlob("external_directory", rule.permission) && (matchesGlob(dir, rule.pattern) || matchesGlob(`${dir}/*`, rule.pattern))))
    .map(dir => ({ permission: "external_directory", pattern: `${dir}/*`, action: "allow" }));
}

// Exact native Read patterns are formed by the backend from validated files.
// A file declaration grants neither external_directory nor edit permission.
export function readAllowRules(agentRules = [], scope = [], files = []) {
  const denies = [...agentRules, ...scope].filter(rule => rule.action === "deny");
  return files.filter(({ file, pattern }) => !denies.some(rule =>
    matchesGlob("read", rule.permission) && (matchesGlob(pattern, rule.pattern) || matchesGlob(file, rule.pattern))))
    .map(({ pattern }) => ({ permission: "read", pattern, action: "allow" }));
}

// An ask is authorized only when it carries patterns and every pattern is
// covered by an explicitly authorized scope directory. Empty/absent patterns
// are NEVER authorized (they must end in the terminal blocker, not a hidden
// wait); exact-directory patterns are accepted as a defensive superset.
export function authorizedFor(dirs, patterns) {
  if (!Array.isArray(patterns) || patterns.length === 0) return false;
  return (dirs ?? []).some(dir => patterns.every(pattern => matchesGlob(pattern, `${dir}/*`) || matchesGlob(pattern, dir)));
}

// Merge inherited and newly declared scope directories atomically: the
// operator's explicit declaration is either fully adopted or rejected — never
// silently truncated to a partial scope.
export function mergeScopeDirs(existing = [], incoming = []) {
  const merged = [...new Set([...existing, ...incoming])];
  if (merged.length > 16) throw new Error("MANAGED_SCOPE_LIMIT");
  return merged;
}

// Fair bounded sweep order: pending external asks of already-managed sessions
// come first so a volume of foreign/manual asks cannot starve the sweep's own
// managed line behind the processing bound. This is an ordering heuristic
// only; the authoritative lineage check still runs per ask.
export function orderSweepAsks(pending, managedSessions) {
  const external = (Array.isArray(pending) ? pending : []).filter(item => typeof item?.permission === "string" && typeof item.sessionID === "string");
  const managed = new Set(managedSessions ?? []);
  return [
    ...external.filter(item => managed.has(item.sessionID)),
    ...external.filter(item => !managed.has(item.sessionID)),
  ];
}

export function restrictions(rules) {
  const independent = rules.filter(r => r.permission !== "question" && !remoteRules.some(remote => same(r, remote)));
  const denied = new Set(independent.filter(r => r.action === "deny").map(r => r.permission));
  return independent.filter(r => r.action === "deny" || r.permission !== "*" && (denied.has(r.permission) || denied.has("*")));
}
export function policyDelta(current, agentRules = [], scope = [], scopeDirs = [], readFiles = []) {
  const desired = [
    ...copyableAgentRules(agentRules),
    ...scope,
    ...scopeAllowRules(agentRules, scope, scopeDirs),
    { permission: "bash", pattern: "git *", action: "allow" },
    { permission: "bash", pattern: "/usr/bin/git *", action: "allow" },
    { permission: "bash", pattern: "/bin/git *", action: "allow" },
    // Preserve task/agent denies; only the VM's ordinary commit asks are relaxed.
    ...restrictions(agentRules),
    ...restrictions(scope),
    // Exact newer Read authorization can supersede an ask even when a
    // different file has a deny. Matching denies were filtered above.
    ...readAllowRules(agentRules, scope, readFiles),
    { permission: "question", pattern: "*", action: "deny" },
    ...remoteRules,
  ];
  const suffix = current.slice(-desired.length);
  return suffix.length === desired.length && suffix.every((rule, i) => same(rule, desired[i])) ? [] : desired;
}

// Tokenize literal shell commands without confusing commit-message text with a
// command. This is defense-in-depth, not an arbitrary-process/network sandbox.
export function tokens(command) {
  const out = [];
  let word = "", quote = "", escaped = false, present = false;
  for (const char of command) {
    if (escaped) { if (char !== "\n") word += char; escaped = false; present = true; continue; }
    if (char === "\\" && quote !== "'") { escaped = true; present = true; continue; }
    if (quote) { if (char === quote) quote = ""; else word += char; present = true; continue; }
    if (char === "'" || char === '"') { quote = char; present = true; continue; }
    if (/\s/.test(char) || ";|&()".includes(char)) {
      if (present) out.push(word);
      word = ""; present = false;
      if (";|&()\n".includes(char)) out.push(";");
    } else { word += char; present = true; }
  }
  if (quote || escaped) throw new Error("REMOTE_POLICY_COMMAND_INVALID");
  if (present) out.push(word);
  return out;
}
export function remoteWrite(command, aliases = {}, depth = 0) {
  if (depth > 8) return true;
  const words = tokens(command);
  const writes = new Set(["push", "send-pack", "http-push", "receive-pack"]);
  let start = true;
  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    if (word === ";") { start = true; continue; }
    if (!start) continue;
    const binary = word.split("/").at(-1);
    if (["sh", "bash", "zsh", "dash"].includes(binary)) {
      const flag = words[i + 1];
      if (flag?.startsWith("-") && flag.includes("c") && remoteWrite(words[i + 2] ?? "", aliases, depth + 1)) return true;
    }
    if (/^[A-Za-z_][\w]*=/.test(word) || ["env", "command", "exec", "sudo", "nice", "nohup"].includes(binary)) continue;
    start = false;
    if (["git-send-pack", "git-http-push", "git-receive-pack", "git-http-backend"].includes(binary)) return true;
    if (binary === "git") {
      let j = i + 1;
      const localAliases = { ...aliases };
      while (j < words.length && words[j].startsWith("-")) {
        if (words[j] === "-c" && words[j + 1]?.startsWith("alias.")) {
          const setting = words[j + 1];
          const equal = setting.indexOf("=");
          if (equal > 6) localAliases[setting.slice(6, equal)] = setting.slice(equal + 1);
        }
        if (["-C", "-c", "--git-dir", "--work-tree", "--exec-path", "--config-env"].includes(words[j])) j++;
        j++;
      }
      if (writes.has(words[j])) return true;
      if (words[j] === "credential" && ["approve", "fill"].includes(words[j + 1])) return true;
      if (words[j] === "lfs" && ["push", "upload", "pre-push"].includes(words[j + 1])) return true;
      if (localAliases[words[j]]) {
        const value = localAliases[words[j]];
        if (remoteWrite(value.startsWith("!") ? value.slice(1) : `git ${value}`, localAliases, depth + 1)) return true;
      }
    }
    if (binary === "git-lfs" && ["push", "upload", "pre-push"].includes(words[i + 1])) return true;
    if (binary === "gh" && ["release", "pr", "repo"].includes(words[i + 1]) && !["list", "view", "status", "clone", "diff", "checks", "download"].includes(words[i + 2])) return true;
    if (binary === "gh" && words[i + 1] === "api") {
      const arguments_ = words.slice(i + 2, words.indexOf(";", i + 2) < 0 ? undefined : words.indexOf(";", i + 2));
      if (arguments_.some((arg, index) => ["-f", "-F", "--field", "--raw-field"].includes(arg) || /^(?:--field|--raw-field)=/.test(arg) || ["-X", "--method"].includes(arg) && !["GET", "HEAD", "OPTIONS"].includes(arguments_[index + 1]) || /^--method=/.test(arg) && !/^--method=(GET|HEAD|OPTIONS)$/.test(arg))) return true;
    }
    if (binary === "gh" && words[i + 1] === "auth" && ["login", "setup-git", "refresh", "token"].includes(words[i + 2])) return true;
  }
  return false;
}
export function handback(questions) {
  const items = Array.isArray(questions) ? questions.slice(0, 8) : [];
  const text = value => String(value ?? "").replace(/\r/g, "").slice(0, 2000);
  const decisions = items.map(q => text(q.question)).filter(Boolean);
  const options = items.flatMap(q => Array.isArray(q.options) ? q.options.slice(0, 8).map(o => `${text(o.label)}: ${text(o.description)}`) : []);
  return `INPUT_REQUIRED:\n- decision: ${decisions.join("; ") || "A business decision is required; inspect the attempted question in this turn."}\n- context: The agent requested information needed to continue this work. Native end-user dialogs are disabled for agent-managed sessions.\n- safe_options: ${options.join("; ") || "Supply the missing decision, or keep the dependent work paused."}\n- completed: Work already stored in this session remains available for review.\n- paused: Decision-dependent work; reply through the orchestrator as a normal follow-up in this same session.`;
}

// Terminal report for an unauthorized external_directory permission ask in a
// managed session. The pending ask is rejected with corrective feedback and
// the next provider step of the turn is replaced by this report, so the turn
// ends stored/terminal instead of waiting forever on a UI approval.
export function permissionBlocker(info) {
  const text = value => String(value ?? "").replace(/\r/g, "").slice(0, 500);
  const patterns = (Array.isArray(info?.patterns) ? info.patterns : []).slice(0, 4).map(text).join("; ");
  const permission = text(info?.permission ?? "external_directory");
  return `INPUT_REQUIRED:\n- decision: Permission ${permission} is not authorized for this managed session and was not approved automatically. Requested scope: ${patterns || "unknown"}.\n- context: Interactive permission dialogs cannot be answered in agent-managed noninteractive work. The request was blocked without approval and this turn ends with a readable blocker instead of waiting.\n- safe_options: Have the orchestrator declare the exact scope_read_files for an authorized Read and separately scope_dirs where external access is needed, or resolve the actual permission restriction; then send a normal follow-up in this same session. Explicit denies and tool disables remain binding.\n- completed: Work already stored in this session remains available for review; nothing was approved or bypassed.\n- paused: Work depending on the blocked permission.`;
}

export function protocol(body, url, family = "") {
  if (url.includes("/responses")) return "responses";
  if (family.includes("anthropic") || body?.anthropic_version) return "anthropic";
  if (url.includes(":streamGenerateContent") || url.includes(":generateContent")) return "google";
  if (url.includes("/messages") && body?.max_tokens !== undefined) return "anthropic";
  if (Array.isArray(body?.messages)) return "chat";
  return undefined;
}
export function questionInResponse(raw, kind) {
  const frames = raw.split(/\r?\n\r?\n/).flatMap(frame => {
    const data = frame.split(/\r?\n/).filter(line => line.startsWith("data:")).map(line => line.slice(5).trim()).join("\n");
    try { return data && data !== "[DONE]" ? [JSON.parse(data)] : []; } catch { return []; }
  });
  if (!frames.length) { try { frames.push(JSON.parse(raw)); } catch { return undefined; } }
  const calls = new Map();
  const add = (id, name, args, replace = false) => {
    const call = calls.get(id) ?? { name: "", args: "" };
    if (name) call.name = replace ? name : call.name + name;
    if (typeof args === "string") call.args = replace ? args : call.args + args;
    else if (args) call.args = JSON.stringify(args);
    calls.set(id, call);
  };
  for (const frame of frames) {
    if (kind === "chat") for (const choice of frame.choices ?? []) for (const call of choice.delta?.tool_calls ?? choice.message?.tool_calls ?? []) add(call.index ?? call.id, call.function?.name, call.function?.arguments, !!choice.message);
    if (kind === "responses") {
      if (frame.type === "response.output_item.added" && frame.item?.type === "function_call") add(frame.item.id, frame.item.name, frame.item.arguments, true);
      if (frame.type === "response.function_call_arguments.delta") add(frame.item_id, "", frame.delta);
      for (const item of frame.response?.output ?? frame.output ?? []) if (item.type === "function_call") add(item.id, item.name, item.arguments, true);
    }
    if (kind === "anthropic") {
      if (frame.type === "content_block_start" && frame.content_block?.type === "tool_use") add(frame.index, frame.content_block.name, Object.keys(frame.content_block.input ?? {}).length ? frame.content_block.input : undefined, true);
      if (frame.delta?.type === "input_json_delta") add(frame.index, "", frame.delta.partial_json);
      for (const item of frame.content ?? []) if (item.type === "tool_use") add(item.id, item.name, item.input, true);
    }
    if (kind === "google") for (const candidate of frame.candidates ?? []) for (const part of candidate.content?.parts ?? []) if (part.functionCall) add(calls.size, part.functionCall.name, part.functionCall.args, true);
  }
  for (const call of calls.values()) {
    if (!["question", "business_input"].includes(call.name)) continue;
    try { return { report: handback(JSON.parse(call.args || "{}").questions) }; }
    catch { return { report: handback([]) }; }
  }
}
export function responseUsage(raw, kind) {
  let usage = {};
  const values = raw.split(/\r?\n/).filter(line => line.startsWith("data:")).map(line => line.slice(5).trim());
  if (!values.length) values.push(raw);
  for (const value of values) {
    try {
      const frame = JSON.parse(value);
      const next = kind === "responses" ? frame.response?.usage ?? frame.usage : kind === "google" ? frame.usageMetadata : frame.usage ?? frame.message?.usage;
      if (next) usage = { ...usage, ...next };
    } catch { /* SSE event/comment/[DONE], not usage. */ }
  }
  return usage;
}
export function terminalResponse(report, kind, streaming = true, usage = {}) {
  const id = "ocvm-handback";
  const event = (type, value) => `event: ${type}\ndata: ${JSON.stringify(value)}\n\n`;
  let body;
  if (kind === "chat") {
    const base = { id, object: "chat.completion.chunk", created: 0, model: "ocvm-terminal" };
    const tokens = { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0, ...usage };
    body = streaming ? `data: ${JSON.stringify({ ...base, choices: [{ index: 0, delta: { role: "assistant", content: report }, finish_reason: null }] })}\n\ndata: ${JSON.stringify({ ...base, choices: [{ index: 0, delta: {}, finish_reason: "stop" }], usage: tokens })}\n\ndata: [DONE]\n\n` : JSON.stringify({ ...base, object: "chat.completion", choices: [{ index: 0, message: { role: "assistant", content: report }, finish_reason: "stop" }], usage: tokens });
  } else if (kind === "responses") {
    const message = { id: "ocvm-message", type: "message", role: "assistant", status: "completed", content: [{ type: "output_text", text: report, annotations: [] }] };
    const response = { id, object: "response", created_at: 0, status: "completed", model: "ocvm-terminal", output: [message], usage: { input_tokens: 0, output_tokens: 0, total_tokens: 0, ...usage } };
    body = streaming ? event("response.created", { type: "response.created", response: { ...response, status: "in_progress", output: [] } }) + event("response.output_item.added", { type: "response.output_item.added", output_index: 0, item: { ...message, status: "in_progress", content: [] } }) + event("response.content_part.added", { type: "response.content_part.added", item_id: message.id, output_index: 0, content_index: 0, part: { type: "output_text", text: "", annotations: [] } }) + event("response.output_text.delta", { type: "response.output_text.delta", item_id: message.id, output_index: 0, content_index: 0, delta: report }) + event("response.output_item.done", { type: "response.output_item.done", output_index: 0, item: message }) + event("response.completed", { type: "response.completed", response }) : JSON.stringify(response);
  } else if (kind === "anthropic") {
    const message = { id, type: "message", role: "assistant", model: "ocvm-terminal", content: [{ type: "text", text: report }], stop_reason: "end_turn", stop_sequence: null, usage: { input_tokens: 0, output_tokens: 0, ...usage } };
    body = streaming ? event("message_start", { type: "message_start", message: { ...message, content: [], stop_reason: null } }) + event("content_block_start", { type: "content_block_start", index: 0, content_block: { type: "text", text: "" } }) + event("content_block_delta", { type: "content_block_delta", index: 0, delta: { type: "text_delta", text: report } }) + event("content_block_stop", { type: "content_block_stop", index: 0 }) + event("message_delta", { type: "message_delta", delta: { stop_reason: "end_turn", stop_sequence: null }, usage: { output_tokens: message.usage.output_tokens } }) + event("message_stop", { type: "message_stop" }) : JSON.stringify(message);
  } else if (kind === "google") {
    const result = { candidates: [{ index: 0, content: { role: "model", parts: [{ text: report }] }, finishReason: "STOP" }], usageMetadata: { promptTokenCount: 0, candidatesTokenCount: 0, totalTokenCount: 0, ...usage } };
    body = streaming ? `data: ${JSON.stringify(result)}\n\n` : JSON.stringify(result);
  } else throw new Error("MANAGED_COMPLETION_PROTOCOL_UNSUPPORTED");
  return new Response(body, { headers: { "content-type": streaming ? "text/event-stream" : "application/json" } });
}
